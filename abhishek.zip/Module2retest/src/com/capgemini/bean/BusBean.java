package com.capgemini.bean;

import java.time.LocalDate;
import java.util.Date;

public class BusBean {

	public BusBean() {
		// TODO Auto-generated constructor stub
		//BusBean () class is defined .
	}
 
	
	private int busid;
	public BusBean(int busid, String busType, String fromStop, String toStop,
			long fare, int availableseats, Date dateofjourney) {
		super();
		this.busid = busid;
		this.busType = busType;
		this.fromStop = fromStop;
		this.toStop = toStop;
		this.fare = fare;
		this.availableseats = availableseats;
		this.dateofjourney = dateofjourney;
	}
	//Constructor being defined.


	private String busType;
	public BusBean(String busType, String fromStop, String toStop, long fare,
			int availableseats, Date dateofjourney) {
		super();
		this.busType = busType;
		this.fromStop = fromStop;
		this.toStop = toStop;
		this.fare = fare;
		this.availableseats = availableseats;
		this.dateofjourney = dateofjourney;
	}


	private String fromStop;
	@Override
	public String toString() {
		return "BusBean [busid=" + busid + ", busType=" + busType
				+ ", fromStop=" + fromStop + ", toStop=" + toStop + ", fare="
				+ fare + ", availableseats=" + availableseats
				+ ", dateofjourney=" + dateofjourney + "]";
	}
	public int getBusid() {
		return busid;
	}
	public void setBusid(int busid) {
		this.busid = busid;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public String getFromStop() {
		return fromStop;
	}
	public void setFromStop(String fromStop) {
		this.fromStop = fromStop;
	}
	public String getToStop() {
		return toStop;
	}
	public void setToStop(String toStop) {
		this.toStop = toStop;
	}
	public long getFare() {
		return fare;
	}
	public void setFare(long fare) {
		this.fare = fare;
	}
	public int getAvailableseats() {
		return availableseats;
	}
	public void setAvailableseats(int availableseats) {
		this.availableseats = availableseats;
	}
	


	private String toStop;
	private long fare;
	private int availableseats;
	private Date dateofjourney;
	public Date getDateofjourney() {
		return dateofjourney;
	}
	public void setDateofjourney(Date dateofjourney) {
		this.dateofjourney = dateofjourney;
	}
	
}
