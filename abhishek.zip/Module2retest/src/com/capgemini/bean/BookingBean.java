package com.capgemini.bean;

import java.time.LocalDate;
//Bean class defined.
public class BookingBean {

	public BookingBean() {
		// TODO Auto-generated constructor stub
		//generating the getter setter for the following fields.
	}

	
	private int busId;
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	public int getNoOFSeats() {
		return noOFSeats;
	}
	public void setNoOFSeats(int noOFSeats) {
		this.noOFSeats = noOFSeats;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getCustID() {
		return custID;
	}
	public void setCustID(String custID) {
		this.custID = custID;
	}


	private int noOFSeats;
	//generating constructor.
	
	public BookingBean(int busId, int noOFSeats, String custID) {
		super();
		this.busId = busId;
		this.noOFSeats = noOFSeats;
		this.custID = custID;
	}


	private int bookingId;
	private String custID;
}
