package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;




import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;

import com.capgemini.util.BusConnection;



public class BusDaoImpl implements BusDao {
	private Connection connect;
	static Logger myLogger = Logger.getLogger("myLogger");//logger defined .....
	BusConnection util;

	public BusDaoImpl() {
		// TODO Auto-generated constructor stub
		try {
			util = new BusConnection();
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		connect=util.getConnection();
		myLogger.info( "Connection Procured in EmpdaoImpl.");
	}

	@Override
	public List<BusBean> retrieveBusDetails() throws BookingException {//list function..
		// TODO Auto-generated method stub
		myLogger.info("retrieve the details");
        List<BusBean> empList =new ArrayList<>();
		
		try (
			Statement Stmt =connect.createStatement();
			ResultSet  rs= Stmt.executeQuery("select * from BusDetails");)
	{
			while(rs.next())
		{
			int busid= rs.getInt("busId");
			String bustype =rs.getString("bustype");
			String fromStop =rs.getString("fromStop");
			String toStop =rs.getString("toStop");
			long fare= rs.getLong("fare");
			int count= rs.getInt("availableseats");
			Date date=rs.getDate("dateofjourney");
		
			
			empList.add (new BusBean (busid,bustype,fromStop,toStop,fare,count,date));
			//System.out.println(empNo+"\t"+empNm +"\t"+empSal);
		}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BookingException("cannot produce the result");
		}
		return empList;
		
	}
		
	

	@Override
	public int bookTicket(BookingBean cust) throws BookingException {
		// TODO Auto-generated method stub
		int a=bookingid();
		String qry="insert into BookingDetails( bookingId, custId,busId, noOfSeats) values (?,?,?,?)";
		
		ResultSet rs=null;
		myLogger.info("inserted into booking details");
		
		int recsAffected=0;
		try(
		PreparedStatement stmt = connect.prepareStatement(qry);)//we can prevent from injection .
		{
		stmt.setInt(1, a);//1-the position of the ? mark and second the variable name
		stmt.setString(2, cust.getCustID());
		stmt.setDouble(3, cust.getBusId());
		
		stmt.setInt(4,cust.getNoOFSeats());
		
		
		
		
		
		
		recsAffected= stmt.executeUpdate();//return type is integer type so we dont need the result set 
		myLogger.info( "update was executed");
		if(recsAffected==1)
		{
			boolean x=update(cust.getBusId(),cust.getNoOFSeats());
			cust.setBookingId(a);
		   return 1;
		}
		else
			return 0;
		
		
		}
		 catch (SQLException e) {
				throw new BookingException("connection opening failed",e);
				
			}		
		

		
	}
	//generating the bookingid.
	public int bookingid() throws BookingException {
		// TODO Auto-generated method stub
		String qry="select Booking_Id_Seq.nextval from dual";
		ResultSet recsAffected=null;
        int a=0;
		try(
		PreparedStatement stmt = connect.prepareStatement(qry);)//we can prevent from injection .
		{
        	
		//TruckBean cust=new TruckBean();
		
		recsAffected= stmt.executeQuery();
		while(recsAffected.next())
		{
		a=recsAffected.getInt(1);
		}
		
		}
		 catch (SQLException e)
			{
				throw new BookingException("connection opening failed",e);
				
			}		
		
					
				
		
		return a;
	
		
		//update function is being introduced.
		
	}
	public boolean update(int n,int x) throws BookingException {
		// TODO Auto-generated method stub
		myLogger.info( "update is succesful");
		String qry="update busDetails set availableSeats=availableSeats-?  where busid=?";
		ResultSet rs=null;
		int recsAffected=0;
	
		

		try(
		PreparedStatement stmt = connect.prepareStatement(qry);)//we can prevent from injection .
		{
        	
		BookingBean cust=new BookingBean();
		stmt.setInt(1,x);
		stmt.setInt(2, n);
		recsAffected= stmt.executeUpdate();//return typen is int type so we dont need the result set 
		
		}
		 catch (SQLException e)
			{
				throw new BookingException("connection opening failed",e);
				
			}		
		
					
				
		
		return (recsAffected ==1 )?true :false;
	
	}
//validate the bustid
	@Override
	public boolean validateBusId(int bus) throws BookingException {
		// TODO Auto-generated method stub
ArrayList<Integer>busid =new ArrayList<>();
		
		try(Statement Stmt =connect.createStatement();
				ResultSet  rs= Stmt.executeQuery("select busid from busDetails");) 
		{
			while (rs.next())
			{
				int id=rs.getInt("busid");
				busid.add(id);
				
				
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BookingException("cannot produce the result");
		}
		if(busid.contains(bus))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	//validation of no. of seats 

	@Override
	public boolean noofseats(int n, int busid) throws BookingException {
		// TODO Auto-generated method stub
		BookingBean cust=new BookingBean();
		ResultSet rs=null;
		int m=0;
		//System.out.println("asdf");
		String qry="select availableseats from busDetails where busId=?";
		try(PreparedStatement stmt = connect.prepareStatement(qry);)
		{
			
			//System.out.println(truckid);
			stmt.setInt(1,busid);
			rs=stmt.executeQuery();
			if(rs.next())
			m=rs.getInt(1);
			}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BookingException("cannot produce the result");
		}
		if((n <= m)&&(n>0))
		{
			return true;
		}
		else
		{
			return false;
		}
				
		
	}
	
	}


