package com.capgemini.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.capgemini.exception.BookingException;


public class BusConnection {
	private Connection connect;


	public BusConnection() throws BookingException{
		// TODO Auto-generated constructor stub
		PropertyServices propservices=new PropertyServices();
		String url=propservices.getPropValue("url");
		String username =propservices.getPropValue("username");
		String password=propservices.getPropValue("password");
	    try {
			connect = DriverManager.getConnection(url, username,password);
			} catch (SQLException e) {
				throw new BookingException("connection opening failed",e);
				
			}		
	}
	public Connection getConnection(){
		return connect;
		
	}

}
