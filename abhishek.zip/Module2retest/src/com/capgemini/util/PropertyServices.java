package com.capgemini.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import com.capgemini.exception.BookingException;

public class PropertyServices {
	private Properties props;

	public PropertyServices() throws BookingException {
		// TODO Auto-generated constructor stub
		props =new Properties();
		//FileInputStream fis= null;
		try (
			 FileInputStream fis= new FileInputStream("connection.properties");)
			 {
			
			props.load(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new BookingException ("Property file missing",e);
		}
		//it will load all key value pairs
		
		
	}

	public String getPropValue(String prop)
	{
	 return	props.getProperty(prop);

	}


	}


