package com.capgemini.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bean.BookingBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;



public class BusTest {
	//Junit is being introduced.
	BusDaoImpl check=new BusDaoImpl();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
// the test case is introduced .
	@Test
	public void test() {
		BookingBean cust=new BookingBean();
		cust.setBusId(1);
		cust.setCustID("A12345");
		cust.setNoOFSeats(2);
		
		try
		{
			int bookingid=check.bookingid();
			assertEquals(1010,bookingid);
		}catch(BookingException e)
		{
		fail("Test failed");
	}

}
}
