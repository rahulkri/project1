package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;



public interface BusService extends AutoCloseable {
	public List<BusBean> retrieveBusDetails() throws BookingException ;
	int bookTicket(BookingBean cust) throws BookingException;
	public boolean validateBusId(int bus) throws BookingException;
	public boolean validateCustId(String custid);
	public boolean noofseats(int n,int busid) throws BookingException;

}
