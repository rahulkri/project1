package com.capgemini.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;


public class BusServiceImpl implements BusService {
	private BusDao dao;

	public BusServiceImpl() {
		// TODO Auto-generated constructor stub
		dao=new BusDaoImpl();
	}

	@Override
	public List<BusBean> retrieveBusDetails() throws BookingException {
		// TODO Auto-generated method stub
		return dao.retrieveBusDetails();
	}

	@Override
	public int bookTicket(BookingBean cust) throws BookingException {
		// TODO Auto-generated method stub
		return dao.bookTicket(cust);
	}

	@Override
	public boolean validateBusId(int bus) throws BookingException {
		// TODO Auto-generated method stub
		return  dao.validateBusId(bus);
	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}
//validation of custid.
	@Override
	public boolean validateCustId(String custid) {
		// TODO Auto-generated method stub
		boolean patternMatch;
		Pattern pt= Pattern.compile("[A-Z][1-9][0-9]{5}");
		Matcher match=pt.matcher(custid);
		if( match.matches())
		{
			return true;
		}
		else 
		{
			return false;
		}
		
		
	}

	@Override
	public boolean noofseats(int n, int busid) throws BookingException {
		// TODO Auto-generated method stub
		return dao.noofseats(n, busid);
	}

}
