package com.capgemini.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.BusService;
import com.capgemini.service.BusServiceImpl;





public class MainClient {
	//the main class defined.
	
	public static void main(String[] args) {
		// TODO Auto-generated method stubSystem.out.println("Please see the bus details below");
		try (BusService services=new BusServiceImpl();)
		{
		Scanner kbdInput=new Scanner(System.in);
		
		int choice= 0;
		
		do
		{
	
		System.out.println("Menu...");
		System.out.println("1.Book Ticket");
		System.out.println("2.Exit");
		
		choice= kbdInput.nextInt();
		System.out.println("Enter a choice");
		switch(choice)
		{
		
		case 1: 
		{
			//Adding the new details
			List<BusBean> empList=null;
			try {
				empList = services.retrieveBusDetails();
			} catch (BookingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for(BusBean emp:empList)
			System.out.println(emp);
			System.out.println("Enter Details....");
			boolean empNoValid=true;
			String custid=null;
			do
			{
			System.out.println("Enter customer id");
			custid=kbdInput.next();
			empNoValid=services.validateCustId(custid);
			
	
			}while(!empNoValid);
			boolean empNoValid1=true;
			int busid=0;
			do
			{
			System.out.println("Please enter the busid ");
			 busid=kbdInput.nextInt();
			empNoValid1=services.validateBusId(busid);
			}while(!empNoValid1);
			boolean empNoValid2=true;
			int count=0;
			do{
			System.out.println("Enter number of seats ");
		    count=kbdInput.nextInt();
		    empNoValid2=services.noofseats(count, busid);
			}while(!empNoValid2);
			
			BookingBean cust =new BookingBean(busid,count,custid);
			int isSucc=1;
			try {
				isSucc = services.bookTicket(cust);
			} catch (BookingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(isSucc==1)
			{
				System.out.println("Thank you.Your booking id is"+ " "+cust.getBookingId());
				
			}
			else
			{
				System.out.println("Sorry No seats Available");
			}
			break;
		}
		case 2: {//Exit.
			System.out.println("thanks and visit again");
			break;
		}
		

	}
	}while(choice !=2);

		}catch (BookingException e) {
			// TODO Auto-generated catch block
			System.out.println("Could not processs.");;
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			System.out.println("could not process.");
		} 
	}
}
