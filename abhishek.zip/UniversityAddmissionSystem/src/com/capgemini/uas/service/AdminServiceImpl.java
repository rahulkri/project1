package com.capgemini.uas.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.uas.dao.AdminDaoImpl;
import com.capgemini.uas.dao.IAdminDao;
import com.capgemini.uas.dto.ApplicationBean;
import com.capgemini.uas.dto.ProgramOfferedBean;
import com.capgemini.uas.dto.ProgramScheduledBean;
import com.capgemini.uas.exception.UniversityException;

public class AdminServiceImpl implements IAdminService {
private IAdminDao dao;
public AdminServiceImpl()
{
	dao=new AdminDaoImpl();
}
	@Override
	public boolean addProgramOffered(ProgramOfferedBean pOffered)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.addProgramOffered(pOffered);
	}

	@Override
	public boolean deleteProgramOffered(String programName)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.deleteProgramOffered(programName);
	}

	@Override
	public int addProgramScheduled(ProgramScheduledBean pScheduled)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.addProgramScheduled(pScheduled);
	}

	@Override
	public boolean deleteProgramScheduled(String programId)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.deleteProgramScheduled(programId);
	}
	@Override
	public List<ProgramScheduledBean> getAllDetails()
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.getAllDetails();
	}
	@Override
	public List<String> getAllScheduleId() throws UniversityException {
		// TODO Auto-generated method stub
		return dao.getAllScheduleId();
	}
	@Override
	public List<ApplicationBean> getAllConfirmedDetails(String schProgramId)
			throws UniversityException {
		// TODO Auto-generated method stub
		return dao.getAllConfirmedDetails(schProgramId);
	}
	@Override
	public List<String> getAllProgramName() throws UniversityException {
		// TODO Auto-generated method stub
		return dao.getAllProgramName();
	}
	public boolean validateProgramDescription(String pDesc)
	{
		
		Pattern pt= Pattern.compile("[A-Za-z]{1,4}");
		Matcher match=pt.matcher(pDesc);
		if( match.matches())
		{
			return true;
		}
		else 
		{
			return false;
		}
		
		
	}
	@Override
	public List<String> getAllScheduleNames() throws UniversityException {
		// TODO Auto-generated method stub
		return dao.getAllScheduleNames();
	}
	public boolean validateLocation(String location)
	{
		
		Pattern pt= Pattern.compile("[A-Za-z]");
		Matcher match=pt.matcher(location);
		if( match.matches())
		{
			return true;
		}
		else 
		{
			return false;
		}
		
		
	}

}
